### 2.0.0: 2020-04-23
  * 🔥 200 New Icons
  * 🔥 SVG Icons by Lona
  * 🔥 SVG Sprite by Lona
  * 🔥 Styled Components - ⚛️ React JS
  * 🔥 Local Styled Components
  * 🔥 Figma Components - https://css.gg/fig
  * 🔥 Adobe XD Components - https://css.gg/xd

### 1.0.6: 2020-01-15
  * Icon: Dribbble - Fix: Gradient outdated direction syntax

### 1.0.5: 2020-01-12
  * Fix: Gradient outdated direction syntax

### 1.0.4: 2019-01-11
  * Add SCSS file
  * Add icon Battery Full
  * Change Battery to 50% filled

### 1.0.0: 2019-01-11
  * Init